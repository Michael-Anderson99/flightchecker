var express = require('express');
var bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient

var app = express();

app.use(bodyParser.json())

app.use(bodyParser.urlencoded({ extended: true }))

var url = 'mongodb+srv://michaeladmin:Michael1@flightchecker-md9lq.mongodb.net/test?retryWrites=true&w=majority'

MongoClient.connect(url, { useUnifiedTopology: true })
    .then(client => {

    console.log('Connected to Database')
    const db = client.db('Account')
    const userCollection = db.collection('users')


    app.post('/signup', (req, res) => {
        


        userCollection.insertOne(req.body)
              .then(result => {
                    console.log(result)
                    res.redirect('/')
              })
              .catch(error => console.error(error))
          })


    

    
    });

var users = [
    {
        username: '',
        email: '',
        password: '',
        
    }
];

var products = [
{
    id:1,
    name: 'football'
},
{
    id:2,
    name: 'xbox'
}];

var currentId=2;

var PORT = process.env.PORT || 3000

app.use(express.static(__dirname)); 
app.use(bodyParser.json());
app.get('/products', function(req, res){
    res.send({products: products});

});

app.post('/products', function(req, res){
    var productName = req.body.name;
    currentId++;
    products.push({
        id: currentId,
        name: productName
    })
    res.send('Successfully created object');
})

app.get('/', function(req,res){
    return('index.html')

})

app.listen(PORT, function() {
    console.log('Server hears ya on ' + PORT);
});




            
