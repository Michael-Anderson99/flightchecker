var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient

var app = express();

app.use(bodyParser.json())

app.use(bodyParser.urlencoded({ extended: true }))

var url = 'mongodb+srv://michaeladmin:Michael1@flightchecker-md9lq.mongodb.net/test?retryWrites=true&w=majority'

var testFlight = [
    {
        destination: 'Madrid',
        airline: 'Ryanair',
        date: '02/07/20'
    },
]

MongoClient.connect(url, { useUnifiedTopology: true })
    .then(client => {

    console.log('Connected to Database')//log successful connection to mongo
    const db = client.db('Flightchecker') //connect to database
    const flightCollection = db.collection('flights')//connect to the flight collection to read data
    const userCollection = db.collection('users')//connect to user collection to read data
    


    app.post('/signup', (req, res) => {

       var u1 = {userfield: req.body.userfield}
       result =  userCollection.find(u1).toArray(function(err, result) {  
        if (err) throw err;
        console.log(result)
        if(result.length != 1)
        {
             console.log("This user does not exist")

                var p1 = req.body.pass1
                var p2 = req.body.pass2

                if(p1 == p2)
                {
                    userCollection.insertOne(req.body)
                    .then(result =>
                    {
                        console.log(result)
                        res.redirect('index.html')
                    })
                    .catch(error => console.error(error))//end then catch
                    }
                    else
                    {
                      console.log('boo')
                      res.redirect("login.html");

                    }//end else
                    

             res.redirect("login.html");
        }
        else
        {
           console.log("This user exists")
            res.redirect('login.html')
           
        }

       }); 
})//end signup


    app.post('/userlogin', (req, res) => {

        var query = {userfield: req.body.userfield, pass: req.body.pass}

        result =  userCollection.find(query).toArray(function(err, result) 
        {
            if (err) throw err;
            console.log(result);

            if(result.length != 1)
            {
                res.redirect('login.html')
            }
            else
            {
                console.log('we found ya ')
                res.redirect('index.html')
            }
             
        })


    })//end userlogin
    

    app.post('/flightSearch', (req, res) => {
        
       
        var queryInput = { destination: req.body.search}

        result =  flightCollection.find(queryInput).toArray(function(err, result) {
            if (err) throw err;
            console.log(result);
            
        
            res.redirect('/')
        });
      
     });//end flightSearch



  });//end mongoClient





var users = [
    {
        username: '',
        email: '',
        password: '',
        
    }
];

var products = [
{
    id:1,
    name: 'football'
},
{
    id:2,
    name: 'xbox'
}];

var currentId=2;

var PORT = process.env.PORT || 3000

app.use(express.static(__dirname)); 
app.use(bodyParser.json());
app.get('/products', function(req, res){
    res.send({products: products});

});

app.post('/products', function(req, res){
    var productName = req.body.name;
    currentId++;
    products.push({
        id: currentId,
        name: productName
    })
    res.send('Successfully created object');
})

app.get('/', function(req,res){
    return('index.html')

})

app.listen(PORT, function() {
    console.log('Server hears ya on ' + PORT);
});




