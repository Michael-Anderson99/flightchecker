var express = require('express');
const jwt = require('jsonwebtoken')
var bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient
const two_hours = 100*60*60*2
var app = express();


process.env.SECRET_KEY = 'secretkey'

var PORT = process.env.PORT || 3000

app.use(express.static(__dirname)); 
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

var url = 'mongodb+srv://michaeladmin:Michael1@flightchecker-md9lq.mongodb.net/test?retryWrites=true&w=majority'

app.listen(PORT, function() {
    console.log('Server hears ya on ' + PORT);
});

var aerlingusreview = [
{
    id: 1,
    destination: 'Madrid',
    review: 'great service good food'

}
];
var currentId=1;

MongoClient.connect(url, { useUnifiedTopology: true })
    .then(client => {

    console.log('Connected to Database')//log successful connection to mongo
    const db = client.db('Flightchecker') //connect to database
    const flightCollection = db.collection('flights')//connect to the flight collection to read data
    const userCollection = db.collection('users')//connect to user collection to read data
    


    app.post('/signup', (req, res) => 
    {

       var u1 = {userfield: req.body.userfield}
       result =  userCollection.find(u1).toArray(function(err, result) 
       {  
            if (err) throw err;
            console.log(result)
            if(result.length != 1)
            {
             console.log("This user does not exist")

                var p1 = req.body.pass1
                var p2 = req.body.pass2

                if(p1 == p2)
                {
                    userCollection.insertOne(req.body)
                    .then(result =>
                    {
                        console.log(result)
                        res.redirect('login.html')
                    })
                    .catch(error => console.error(error))//end then catch
                }
                else
                {
                    console.log('boo')
                    res.redirect("login.html");

                }//end password comp if/else
                    

                res.redirect("login.html");
            }//end count test
        else
        {
           console.log("This user exists, please login")
            res.redirect('login.html')
           
        }

    }); //endcheck
})//end post/signup


    app.post('/userlogin', (req, res) => 
    {
        //set the user details im going to query the collection for
        var query = {userfield: req.body.userfield, pass1: req.body.pass1}

        result =  userCollection.find(query).toArray(function(err, result) 
        {
            if (err) throw err;

            console.log(result);

            if(result.length != 1)
            {
                console.log('no luck')
                res.redirect('login.html')
            }
            else
            {
                /*const payload = 
                {
                    username: req.body.userfield
                }
                
                let token = jwt.sign(payload, 'secretkey', { algorithm: 'RS256' }, function(err, token) {
                    console.log(token);
                  });*/
                
                  res.redirect('/')

            }//end if else
        })//end query
    })//end userlogin
    
    app.get('/AerLingus',  (req, res) =>
    {
        /* if(verifToke(req, res))
        {
        jwt.verify(req.token, 'secretkey', (error, authConfData) => {
            if(error) {
                res.sendStatus(403);
            }
            else{

                res.render('AerLingus.html')
            };
        })}
        */
       res.render('AerLingus.html')
    });
        
    app.post('/editaccount', (req, res) =>
    {
        var query = {userfield: req.body.userfield, pass1: req.body.pass1}
        var newPassword = { $set: { pass1: req.body.pass2, pass2: req.body.pass2} };

        result =  userCollection.find(query).toArray(function(err, result) 
        {
            if (err) throw err;

            console.log(result);

            if(result.length != 1)
            {
                console.log(result)
                console.log('no luck')
                res.redirect('login.html')
            }   
            else
            {
                userCollection.updateOne(query, newPassword, function(err, result) 
                {
                    if(err) throw err;
                    console.log('should work chief')
                    res.redirect('/')
                });//close query to update
            }//close if else 
        })//close query to find


    });//close post request /editaccount

    app.post('deleteaccount', (req, res) =>
    {
        var query= {userfield: req.body.userfield, emailfield: req.body.emailfield, pass1: req.body.pass1}

        userCollection.deleteOne(query , function(req, res)
        {
            if (err) throw err

            console.log('should work')

        })//close delete query

    });//close delete request

    app.post('/flightSearch', (req, res) => 
    {
        console.log(req.headers.referer)
        //search the flight collection in the database for any flight, hence empty .find({}) method
        flights = flightCollection.find({}).toArray(function(err, flights) {
        if (!err) {

          // create HTML table to output my flight results to
          var output = '<html><header><title>Flights List from DB</title></header><body>';
          output += '<h1>list of flights as received from the database</h1>';
          output += '<table border="1"><tr><td><b>' + 'Destination' + '</b></td><td><b>' + 'airline' + '</b></td></tr>';

          // adding to table function for each flight in collection
          flights.forEach(function(flights)
          {
            output += '<tr><td>' + flights.destination + '</td><td>' + flights.airline + '</td></tr>';
          });

          // write HTML output (ending)
          output += '</table></body></html>'

          // send output back
          res.send(output);

          // log data to the console as well
          console.log(flights);
        }
      });
      
     });//end flightSearch

     
    app.get('/', function(req,res){
        console.log('hello')
        res.render('index.html', {success: false, errors: req.session.errors})

    })


  });//end mongoClient

function verifToke(req, res)
     {
        const bearerHeader = req.headers['authorize'];

        if(typeof bearerHeader != 'undefined')
        {
            const bearer = bearerHeader.split(' ');
             bToken = bearer[1];
             req.token = bToken;
             return(true, req.token)
             

        }
        else
        {
            res.sendStatus(403);
        }

     }
app.post('/aerlingusreview', function(req, res){
    var productName = req.body.name;
    currentId++;
    aerlingusreview.push({
        id: currentId,
        destination: '',
        review:'',
        
    })
    res.send('Successfully created object');
})
app.get('/aerlingusreview', function(req, res){
    res.send({aerlingusreview: aerlingusreview});   

});







