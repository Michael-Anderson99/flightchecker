$(function() {
    //get or read

    $("#get-button").on('click', function(){
    $.ajax({
        url: '/aerlingusreview',
        contentType: 'application/json',
        success: function(response){
            console.log(response)
            var tbodyEl = $('tbody');

            tbodyEl.html(' ');

            response.review.forEach(function(review){
            tbodyEl.append('\
                <tr>\
                        <td class="id">' + review.id + '</td>\
                        <td><input type="text"\
                            class="name" value="' + review.name +'" \
                        </td>\
                        <td>\
                            <button class="update-button">\
                            UPDATE/PUT</button>\
                            <button class="delete-button">\
                            DELETE</button>\
                        </td>\
                </tr>\
            ')

            })
        }
    });
    });

    $('#create-form').on('submit', function(event){
        event.preventDefault();

        var createInput = $('create-input');

        $.ajax({
            url: '/Aerlingus',
            method:'POST',
            contentType: 'application/json',
            data: JSON.stringify({ name: createInput.val() }),
            success: function(response) {
                console.log(response);
                createInput.val('');
                $('get-button').click();
            }

        });


    });


});